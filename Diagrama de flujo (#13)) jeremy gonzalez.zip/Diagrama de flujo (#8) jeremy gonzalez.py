# 8 asignacion de valores
#variables de entrada
A = 2
B = 5
C = 3
aux = 0

# INICIO
#Leer 
print("A =", A)
print("B =", B)
print("C =", C)
print("AUX =", aux)

# Realizar operaciones
A = A + 3
B = 5 * A
C = B
aux = C
A = B + C
B = aux / C
C = (A + B) * aux

# Imprimir 
print("A =", A)
print("B =", B)
print("C =", C)
print("AUX =", aux)

#FIN
