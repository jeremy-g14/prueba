# 11 CALCULAR SALARIO 💸💸

# Variables de entrada
HT = float(input("Ingrese las horas trabajadas en un mes: "))
SH = float(input("Ingrese el salario por hora: "))
HX = float(input("Ingrese el número de horas extra trabajadas: "))

 #variable de salida SM,SX,ST

 #INICION 💸

#Leer HT,SH,HX
# Calcular salario mensual total
SM =( HT * SH)
SX =( HX * (SH * 2))
ST = (SM + SX)

# Resultados
print("El monto adicional por horas extras es:", SX)
print("El salario total es:", ST)
