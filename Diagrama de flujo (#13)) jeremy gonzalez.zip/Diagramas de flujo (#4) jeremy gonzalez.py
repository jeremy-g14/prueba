# 4 suma de perimetros de un rectangulo

#variable de entrada
A=float(input("ingrese el primer lado : "))
B=float(input("ingrese el segundo lado : "))
C=float(input("ingrese el tercer lado : "))
D=float(input("ingrese el cuarto lado : "))

 # variable de salida P
 
 #INICIO
 #Leer A,B,C,D
print("perimetro del rectangulo : ", end='')
P= print( A + B + C + D )

#IMPRIMIR P

#FIN