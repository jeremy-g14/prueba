# 5 CALCULAR EL AREA DE UN TRAPESIO

#variable de entrada
base1=float(input("ingrese la longitud de la base menor : "))
base2=float(input("ingrese la longitud de la base menor : "))
altura=float(input("ingrese la altura del trapesio : "))

#variable de salida area

#INICIO
#Leer base1.base2,altura
print( "area del trapecio : ", end='')
area= print((( base1 + base2 ) * altura)/2)

#IMPRIMIR area

#FIN