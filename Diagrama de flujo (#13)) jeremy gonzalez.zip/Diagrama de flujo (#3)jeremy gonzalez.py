# 3 CALCULAR AREA DE TRIANGULO

#variable de entrada
b=float(input(" ingrese la base del triangulo : "))
a=float(input("ingrese la altura del triangulo : "))

#variable de salida A
#INICIO
#Leer base,altura
print(" area del triangulo : ", end='')
area=print(( b * a )/2)

#IMPRIMIR area

#FIN