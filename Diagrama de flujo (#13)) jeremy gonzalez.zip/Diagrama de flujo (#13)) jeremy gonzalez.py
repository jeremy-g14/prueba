# 13 CONVERTIDOR DE TEMPERATURA 🌡️
#vvariable de entrada
C=float(input("ingrese la cantida en grado celsius : "))

#variable de salida F,K 🌡️

#INICION
#Leer C

F=(( C * 1.8 ) + 32)
K=( C + 273.15 )

#IMPRIMIR
print("cantidad en fahrenheit : ", F)
print("cantidad en kelvin : ", K)

# FIN