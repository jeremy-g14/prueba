# 1 HAGA UN ALGORITMO QUE SUME DOS VALORES

#variable de entrada
A=float(input("ingrese el primer valor : "))
B=float(input("ingrese el segundo valor : "))

#variable de salida C

#INICION
#Leer A,B
print(" la cantidad total es : ", end='')
C=print(A+B)

#imprimir C

#FIN