# 7 CALCULAR ECUASION LINEAL

#variable de entrada
X=float(input(" ingrese el valor de X para las ecuasiones : "))
# variable de salida A,B,C,D,E,F

#INICIO
#Leer X
A= ( 20-( 7 * X))
B= ( -7 * X) + 2 - ( 10 * X ) + 5
C= ( 4 * X ) + 4 + ( 9 * X ) + 18
D= ( 6 * X )- 5 + ( 8 * X) + 2
E= (( 5 * X) + 78 )/ 28
F= ((( 6 * X  ) - 7 ) / 4 ) + ((( 3 * X ) - 5 ) / 7 )

#IMPRIMIR
print("el valor de  X en la primera ecuasion : ", A)
print("el valor de  X en la segunda ecuasion : ", B)
print("el valor de  X en la tercera ecuasion : ", C)
print("el valor de  X en la cuarta ecuasion : ", D)
print("el valor de  X en la quinta ecuasion : ", E)
print("el valor de  X en la sexta ecuasion : ", F)

#FIN
