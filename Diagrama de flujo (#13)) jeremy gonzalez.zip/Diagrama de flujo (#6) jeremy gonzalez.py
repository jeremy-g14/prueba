# 6 CALCULAR VOLUMEN DE UN PRISMA
#variable de entrada
L=float(input("ingrese el largo de el prisma : "))
A=float(input("ingrese el ancho de el prisma : "))
a=float(input("ingrese el area de el prisma : "))
#variable de salida V
print("volumen del prisma : ", end='')
V= print( L * A * a )

#IMPRIMIR V
#FIN