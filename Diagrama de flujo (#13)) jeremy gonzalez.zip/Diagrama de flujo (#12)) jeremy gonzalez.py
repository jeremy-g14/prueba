# 12 CALCULADOR DE IMC 🩻

#variables de entradas
altura = float(input("Ingresa tu altura en metros: "))
peso = float(input("Ingresa tu peso en kilogramos: "))

# variable de salida imc 🩻

#INICIO
#Leer peso,altura
imc =(peso / (altura ** 2))

# Determinar la categoría del IMC
categoria = ""
if imc < 18.5:
    categoria=("bajo peso")
elif imc < 25:
    categoria=("peso normal")
elif imc < 30:
    categoria=("sobrepeso")
else:
    print("obesidad")

#IMPRIMIR
print("Tu IMC es:", imc)
print("Categoría:", categoria)

#FIN