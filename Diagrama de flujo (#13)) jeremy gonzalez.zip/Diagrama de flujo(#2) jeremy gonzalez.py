# 2 CALCUALAR IMPUESTO

#variable de entrada
precio=float(input("ingrese el precio del producto : "))
cantidad=float(input("ingrese la cantidad del producto : "))
impuestos=float(input("ingrese la cantidad del impuesto : "))

#variable de salida p3

#INICIO
#Leer precio , cantida ,impuesto
print("impuesto del producto : ", end='')
p1=( precio * cantidad )
p2=( p1 * 0.10 )
p3=print( p1 + p2 )

#IMPRIMIR p3

#FIN