# 12 calculador de descuento 🏷🏷️

#variable de entrada
PP=float(input("ingrese el precio del producto : "))
PD=float(input(" ingrese el porcentaje de descuento : "))
IV=float(input(" ingrese el impuesto sobre la venta : "))

#variable de salida
pd=(PP-(PP*PD/100))
pi=(pd+(pd*IV/100))

#inici0

#Leer PP,PD,IV 🏷️

#IMPRIMIR
print("precio con descuento : ",pd)
print("precio final con impuesto incluido : ",pi)

#FIN